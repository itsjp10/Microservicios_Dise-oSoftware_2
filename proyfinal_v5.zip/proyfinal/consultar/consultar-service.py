from flask import Flask, render_template, request, jsonify
from sqlalchemy import create_engine
import psycopg2
import logging
import base64

app = Flask(__name__)

logging.basicConfig(level=logging.DEBUG)
logging.debug("CONSULTAR SERVICE INICIADO")


def consulta(tipo_consulta, numero_documento, tipoDoc):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )        
        cursor = conn.cursor()
        if(tipo_consulta == 1):
            query = f"SELECT COUNT (*) FROM perfil WHERE numero_documento = {numero_documento};"

        elif(tipo_consulta == 2):
            query = f"SELECT * FROM perfil WHERE numero_documento = {numero_documento};"
        elif(tipo_consulta == 3):
            query = f"SELECT imagen FROM imagenes WHERE numero_documento = {numero_documento};"
            cursor.execute(query)
            result = cursor.fetchone()  #acá el resultado puede ser un count o un select con todas las columnas de la tabla
            if result is not None:
                # Devolver los datos binarios de la imagen
                return result[0]
            else:
                # Manejar el caso donde no se encontró ninguna imagen
                return None
        elif(tipo_consulta == 4): #significa que la consulta fue successful
            query = f"INSERT INTO log (descripcion, tipo_documento, numero_documento) VALUES ('Se hizo una consulta', '{tipoDoc}', {numero_documento});"  
            cursor.execute(query)
            conn.commit()
            return 0                       
        elif(tipo_consulta == 5): #significa que la consulta fue successful
            query = f"SELECT tipo_documento FROM perfil WHERE numero_documento = {numero_documento};"   
            cursor.execute(query)
            conn.commit()
            result = cursor.fetchall()  #acá el resultado puede ser un count o un select con todas las columnas de la tabla
            return result[0][0]
        
        cursor.execute(query)
        conn.commit()
        result = cursor.fetchall()  #acá el resultado puede ser un count o un select con todas las columnas de la tabla
        return result
        
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)



@app.route('/consultar')
def consultar_vacio():
    try:                    
        return render_template('consultar.html')
    except:
        #error al intentar "conectarse a la base de datos"
        return render_template('consultar.html')



@app.route('/consultar/<numero_documento>')  #tipo_documento va a ser ti o ce
def consultar(numero_documento):
    try:                    

        count = consulta(1, numero_documento, 'X')[0][0]        
        if (count == 0):
            # no hay ninguna persona con ese documento            
            message = {'type': 'error', 'content': 'Esta persona no existe'}
            return render_template('consultar.html', message=message)
        else:
            #sí hay alguien que tenga ese documento
            datos = consulta(2, numero_documento, 'X') #se van a obtener los datos de esa persona
            tipoDoc = consulta(5, numero_documento, 'X')      
            consulta(4, numero_documento, tipoDoc) #HACER EL LOG DE LA CONSULTA
            img = consulta(3, numero_documento, tipoDoc)
            img64 = base64.b64encode(img).decode('utf-8')    
            return render_template('consultar.html', persona=datos, img64=img64)
            
        
        
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)
        return render_template('consultar.html')
    




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
