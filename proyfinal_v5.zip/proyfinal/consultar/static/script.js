function closeBanner(element) {
    var banner = element.parentNode; // Obtener el elemento padre del span (el banner)
    banner.parentNode.removeChild(banner); // Eliminar el banner del DOM
}

 
//BOTONES

function crear_boton(){
    window.location.href = "http://localhost:5002/crear_personas";
}

function modificar_boton(){
    window.location.href = "http://localhost:5005/actualizar";
}

function consultar_boton(){
    window.location.href = "http://localhost:5001/consultar";
}

function borrar_boton(){
    window.location.href = "http://localhost:5004/eliminar";
}

function consultarlog_boton(){
    window.location.href = "http://localhost:5003/consultar_log";
}


//FUNCIONES DE CONSULTAR

function buscarPorDocumento(){
    var numeroDocumento = document.getElementById('documento').value;
    if (!numeroDocumento || isNaN(numeroDocumento) || numeroDocumento.length > 10) {
        // Mostrar mensaje de error y resaltar el campo.
        mostrarError('numeroDocumento', 'Por favor, ingrese un número de documento válido (hasta 10 dígitos).');
        return;
    }    
    window.location.href = "/consultar/"+numeroDocumento;
    //document.getElementById('formularioEdicion').style.display = 'block';
}

function mostrarError(campo, mensaje) {
    // Muestra el mensaje de error y resalta el campo con un borde rojo.
    var campoElement = document.getElementById(campo);
    var errorElement = document.getElementById(campo + 'Error');
    
    campoElement.classList.add('invalid');
    errorElement.innerText = mensaje;
}

