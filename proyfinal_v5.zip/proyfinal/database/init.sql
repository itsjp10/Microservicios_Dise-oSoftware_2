CREATE TABLE perfil (
    numero_documento INTEGER PRIMARY KEY,
    tipo_documento VARCHAR NOT NULL,
    primer_nombre VARCHAR(255) NOT NULL,
    segundo_nombre VARCHAR(255),
    apellidos VARCHAR(255) NOT NULL,
    fecha_nacimiento VARCHAR NOT NULL,
    genero VARCHAR(255) NOT NULL,
    correo_electronico VARCHAR(255) NOT NULL,
    celular VARCHAR(20) NOT NULL
);

CREATE TABLE imagenes (
    numero_documento INTEGER PRIMARY KEY,
    imagen BYTEA
);


CREATE TABLE log (
    descripcion TEXT NOT NULL,
    tipo_documento VARCHAR NOT NULL,
    numero_documento INTEGER NOT NULL,
    fecha TIMESTAMP DEFAULT current_timestamp
);
