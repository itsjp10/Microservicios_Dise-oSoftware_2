
function activarBoton(boton) {
    document.querySelectorAll('.boton-azul').forEach(function(el) {
        el.classList.remove('activo');
    });
    boton.classList.add('activo');
}

function buscarPorDocumento() {
    var numeroDocumento = document.getElementById('documento').value;
    var cuadroResultados = document.getElementById('cuadro-resultados');

    // Simula los resultados de la consulta (puedes ajustar esto según tu lógica real)
    var resultados = "Resultados para el número de documento " + numeroDocumento;
    cuadroResultados.innerHTML = resultados;
}

function closeBanner(element) {
    var banner = element.parentNode; // Obtener el elemento padre del span (el banner)
    banner.parentNode.removeChild(banner); // Eliminar el banner del DOM
}

 
//BOTONES

function crear_boton(){
    window.location.href = "http://localhost:5002/crear_personas";
}

function modificar_boton(){
    window.location.href = "http://localhost:5005/actualizar";
}

function consultar_boton(){
    window.location.href = "http://localhost:5001/consultar";
}

function borrar_boton(){
    window.location.href = "http://localhost:5004/eliminar";
}

function consultarlog_boton(){
    window.location.href = "http://localhost:5003/consultar_log";
}



//FUNCIONES PARA VALIDAR DATOS DE CREAR PERSONA

function validarFormulario() {
    // Obtener los valores de los campos
    var tipoDocumento = document.getElementsByName('tipo_documento')[0].value;
    var numeroDocumento = document.getElementsByName('numero_documento')[0].value;
    var primerNombre = document.getElementsByName('primer_nombre')[0].value;
    var segundoNombre = document.getElementsByName('segundo_nombre')[0].value;
    var apellidos = document.getElementsByName('apellidos')[0].value;
    var fechaNacimiento = document.getElementsByName('fecha_nacimiento')[0].value;
    var genero = document.getElementsByName('genero')[0].value;
    var correoElectronico = document.getElementsByName('correo_electronico')[0].value;
    var celular = document.getElementsByName('celular')[0].value;
    var imagen = document.getElementsByName('imagen')[0].files[0];

    // Realizar las validaciones
    var errores = '';

    // Validar Tipo de Documento
    if (!['Tarjeta de Identidad', 'Cédula'].includes(tipoDocumento)) {
        errores += 'Tipo de Documento debe ser Tarjeta de Identidad o Cédula.\n';
        document.getElementsByName('tipo_documento')[0].style.borderColor = 'red';
    }

    // Validar Número de Documento
    if (!/^\d{1,10}$/.test(numeroDocumento)) {
        errores += 'Número de Documento debe ser un número de hasta 10 dígitos.\n';
        document.getElementsByName('numero_documento')[0].style.borderColor = 'red';
    }

    // Validar Primer Nombre
    if (!/^[a-zA-Z]+$/.test(primerNombre) || primerNombre.length > 30) {
        errores += 'Primer Nombre debe contener solo letras y tener máximo 30 caracteres.\n';
        document.getElementsByName('primer_nombre')[0].style.borderColor = 'red';
    }

    // Validar Segundo Nombre
    if (!/^[a-zA-Z]*$/.test(segundoNombre) || segundoNombre.length > 30) {
        errores += 'Segundo Nombre debe contener solo letras y tener máximo 30 caracteres.\n';
        document.getElementsByName('segundo_nombre')[0].style.borderColor = 'red';
    }

    // Validar Apellidos
    if (!/^[a-zA-Z\s]+$/.test(apellidos) || apellidos.length > 60) {
        mostrarError('apellidos', 'Por favor, ingrese apellidos válidos (no números, hasta 60 caracteres).');
        return;
    }

    // Validar Fecha de Nacimiento
    // Puedes usar una librería como moment.js para realizar validaciones más detalladas.
    // En este ejemplo, simplemente verificamos que la fecha no esté vacía.
    if (fechaNacimiento === '') {
        errores += 'Fecha de Nacimiento es obligatoria.\n';
        document.getElementsByName('fecha_nacimiento')[0].style.borderColor = 'red';
    }

    // Validar Género
    if (!['Masculino', 'Femenino', 'No Binario', 'Prefiero No Responder'].includes(genero)) {
        errores += 'Género debe ser masculino, femenino, no binario o preferir no responder.\n';
        document.getElementsByName('genero')[0].style.borderColor = 'red';
    }

    // Validar Correo Electrónico
    if (!/\S+@\S+\.\S+/.test(correoElectronico)) {
        errores += 'Correo Electrónico debe tener un formato válido.\n';
        document.getElementsByName('correo_electronico')[0].style.borderColor = 'red';
    }

    // Validar Celular
    if (!/^\d{10}$/.test(celular)) {
        errores += 'Celular debe ser un número de 10 dígitos.\n';
        document.getElementsByName('celular')[0].style.borderColor = 'red';
    }

    // Validar Tamaño de la Foto (Menor a 2MB)
    if (imagen && imagen.size > 2 * 1024 * 1024) {
        errores += 'El tamaño de la foto no debe superar los 2MB.\n';
        document.getElementsByName('imagen')[0].style.borderColor = 'red';
    }

    // Mostrar mensajes de error y detener el envío del formulario si hay errores
    if (errores !== '') {
        alert(errores);
        return false;
    }

    // Limpiar bordes y enviar el formulario si todo está correcto
    limpiarBordes();

    var formulario = document.getElementsByClassName('formulario-personas')[0];
    formulario.submit();
}

function limpiarBordes() {
    // Limpiar los bordes de todos los campos
    var campos = document.getElementsByClassName('formulario-personas')[0].getElementsByTagName('input');
    for (var i = 0; i < campos.length; i++) {
        campos[i].style.borderColor = '';
    }
}

// Agrega este evento al formulario
document.getElementsByClassName('formulario-personas')[0].addEventListener('submit', validarFormulario);


