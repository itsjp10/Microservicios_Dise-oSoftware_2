from flask import Flask, render_template, request, jsonify
from sqlalchemy import create_engine
import psycopg2
import logging

app = Flask(__name__)

message = None

logging.basicConfig(level=logging.DEBUG)
logging.debug("CREAR SERVICE INICIADO")


def insertar_img(numero_documento, datos_imagen):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        #db_string = f'postgresql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}'
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )
        cursor = conn.cursor()
        query = "INSERT INTO imagenes (numero_documento, imagen) VALUES (%s, %s)"
        cursor.execute(query, (numero_documento, datos_imagen))
        logging.debug("imagen agregada!")

        conn.commit()

    except Exception as ex:
        logging.debug("Error insertando la imagen")
        #logging.debug(ex)


def insertar(numero_documento, tipo_documento, primer_nombre, segundo_nombre, apellidos, fecha_nacimiento, genero, correo_electronico, celular):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        #db_string = f'postgresql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}'
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )
        cursor = conn.cursor()
        values = "'"+tipo_documento +"', "+ numero_documento +", '"+ primer_nombre +"', '"+ segundo_nombre +"', '"+apellidos +"', '"+fecha_nacimiento +"', '"+genero +"', '"+correo_electronico +"', '"+ celular+"'"
        query = f"""
            INSERT INTO perfil (tipo_documento, numero_documento, primer_nombre, segundo_nombre, apellidos, fecha_nacimiento, genero, correo_electronico, celular) 
            VALUES 
            ({values});
        """
        logging.debug("persona agreagada!")


        cursor.execute(query)
        query = f"INSERT INTO log (descripcion, tipo_documento, numero_documento) VALUES ('Se creó una persona', '{tipo_documento}', {numero_documento});"
        cursor.execute(query) #nothing to fetch as this query has nothing to show
        conn.commit()         

        #result = cursor.fetchall()

        #for item in result:
            #logging.debug(item)


    except Exception as ex:
        logging.debug(ex)



def consulta(numero_documento):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )
        cursor = conn.cursor()
        query = f"SELECT COUNT(*) FROM perfil WHERE numero_documento = {numero_documento};"
        cursor.execute(query)

        result = cursor.fetchall()

        #for item in result:
            #logging.debug(item)
        #logging.debug("éxito")
        logging.debug(result)
        return result
        

    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)




@app.route('/crear_personas', methods=['GET', 'POST'])
def crear_persona():

    global messages

    if request.method == 'POST':
        try:        
            global message
            tipo_documento = request.form['tipo_documento']
            numero_documento = request.form['numero_documento']
            primer_nombre = request.form['primer_nombre']
            segundo_nombre = request.form['segundo_nombre']
            apellidos = request.form['apellidos']
            fecha_nacimiento = request.form['fecha_nacimiento']
            genero = request.form['genero']
            correo_electronico = request.form['correo_electronico']
            celular = request.form['celular']

            imagen = request.files['imagen']
            datos_imagen = imagen.read()
            
            count = consulta(numero_documento)[0][0]
            logging.debug("Count es:")
            logging.debug(count)

            if (count == 0):
                insertar(numero_documento, tipo_documento, primer_nombre, segundo_nombre, apellidos, fecha_nacimiento, genero, correo_electronico, celular)
                insertar_img(numero_documento, datos_imagen)
                message = {'type': 'success', 'content': 'Persona agregada con éxito'}
                return render_template('crear_persona.html', message=message)
            else:
                message = {'type': 'error', 'content': 'Esta persona ya existe'}
                return render_template('crear_persona.html', message=message)
                
            
            
        except:
            message = {'type': 'error', 'content': 'Error. Por favor revise la conexión a la base de datos'}
            return render_template('crear_persona.html', message=message)
                
    else:
        # Si es una solicitud GET, simplemente renderiza el formulario HTML
        message = {'type': 'none', 'content': ''}
        return render_template('crear_persona.html')




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)