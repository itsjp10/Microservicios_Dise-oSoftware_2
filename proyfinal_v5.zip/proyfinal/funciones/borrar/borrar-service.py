from flask import Flask, render_template, request, jsonify
from sqlalchemy import create_engine
import psycopg2
import logging

app = Flask(__name__)

messages = []

logging.basicConfig(level=logging.DEBUG)
logging.debug("BORRAR SERVICE INICIADO")


def log(numero_documento):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )
        cursor = conn.cursor()        
        query = f"SELECT tipo_documento FROM perfil WHERE numero_documento = {numero_documento};"   
        cursor.execute(query)
        conn.commit()
        result = cursor.fetchall()  #acá el resultado puede ser un count o un select con todas las columnas de la tabla
        return result[0][0] #DEVUELVE EL TIPO DE DOCUMENTO

    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)




def consulta(tipo_consulta, numero_documento):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )       
        cursor = conn.cursor()
        if(tipo_consulta == 1):
            logging.debug("entrando consultar el doc")
            query = f"SELECT COUNT (*) FROM perfil WHERE numero_documento = {numero_documento};"
            cursor.execute(query)
            result = cursor.fetchall()    
            return result

        elif(tipo_consulta == 2): #borrar en perfil e imagenes. También agrega al log
            tipoDoc = log(numero_documento)
            query = f"DELETE FROM perfil WHERE numero_documento = {numero_documento};"
            cursor.execute(query) #nothing to fetch as this query has nothing to show
            conn.commit()
            
            query = f"INSERT INTO log (descripcion, tipo_documento, numero_documento) VALUES ('Se eliminó una persona', '{tipoDoc}', {numero_documento});"
            cursor.execute(query) #nothing to fetch as this query has nothing to show
            conn.commit()

            query = f"DELETE FROM imagenes WHERE numero_documento = {numero_documento};"
            cursor.execute(query) #nothing to fetch as this query has nothing to show
            conn.commit()
            return "exito"
                            
        
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)




@app.route('/eliminar', defaults={'numero_documento': None})
@app.route('/eliminar/<numero_documento>')
def eliminar_persona(numero_documento):
    try:                     
        count = consulta(1, numero_documento)[0][0]        
        if (count == 0):
            # no hay ninguna persona con ese documento
            message = {'type': 'error', 'content': 'Esta persona no existe'}
            return render_template('borrar_persona.html', message=message)
        else:
            #sí hay alguien que tenga ese documento
            consulta(2, numero_documento)[0][0]
            message = {'type': 'success', 'content': 'Esta persona fue eliminada con éxito'}
            return render_template('borrar_persona.html', message=message)
            
        
        
    except:
        #error al intentar "conectarse a la base de datos"
        message = {'type': 'error', 'content': 'Error al eliminar la persona. Por favor revise la conexión a la base de datos'}
        return render_template('borrar_persona.html')    




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)