
function closeBanner(element) {
    var banner = element.parentNode; // Obtener el elemento padre del span (el banner)
    banner.parentNode.removeChild(banner); // Eliminar el banner del DOM
}

 
//BOTONES

function crear_boton(){
    window.location.href = "http://localhost:5002/crear_personas";
}

function modificar_boton(){
    window.location.href = "http://localhost:5005/actualizar";
}

function consultar_boton(){
    window.location.href = "http://localhost:5001/consultar";
}

function borrar_boton(){
    window.location.href = "http://localhost:5004/eliminar";
}

function consultarlog_boton(){
    window.location.href = "http://localhost:5003/consultar_log";
}


//FUNCIONES DE BORRAR PERSONA

function eliminarPersona() {
    // Obtener el número de documento desde el input.
    var numeroDocumento = document.getElementById('documento').value;


    // Redirigir a la ruta con el número de documento.
    window.location.href = "/eliminar/" + numeroDocumento;
}