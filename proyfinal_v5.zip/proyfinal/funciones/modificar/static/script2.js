function verPersona() {
    var numeroDocumento = document.getElementById('numeroDocumento').value;
    if (!numeroDocumento || isNaN(numeroDocumento) || numeroDocumento.length > 10) {
        // Mostrar mensaje de error y resaltar el campo.
        mostrarError('numeroDocumento', 'Por favor, ingrese un número de documento válido (hasta 10 dígitos).');
        return;
    }    
    window.location.href = "/actualizar/"+numeroDocumento;
    //document.getElementById('formularioEdicion').style.display = 'block';
}

function actualizarPersona() {
    

    // Validar campos antes de actualizar la información.
    var numeroDocumento = document.getElementById('numeroDocumentoLA').value;

    var primerNombre = document.getElementById('primerNombre').value;
    if (!primerNombre || !/^[a-zA-Z]+$/.test(primerNombre) || primerNombre.length > 30) {
        mostrarError('primerNombre', 'Por favor, ingrese un primer nombre válido (no números, hasta 30 caracteres).');
        return;
    }

    var segundoNombre = document.getElementById('segundoNombre').value;
    if (!/^[a-zA-Z]*$/.test(segundoNombre) || segundoNombre.length > 30) {
        mostrarError('segundoNombre', 'Por favor, ingrese un segundo nombre válido (no números, hasta 30 caracteres).');
        return;
    }

    var apellidos = document.getElementById('apellidos').value;
    if (!/^[a-zA-Z]+$/.test(apellidos) || apellidos.length > 60) {
        mostrarError('apellidos', 'Por favor, ingrese apellidos válidos (no números, hasta 60 caracteres).');
        return;
    }

    var fechaNacimiento = document.getElementById('fechaNacimiento').value;
    // Validación de la fecha de nacimiento puede requerir una lógica más compleja (se puede usar una biblioteca como moment.js).

    var genero = document.getElementById('genero').value;
    if (!['Masculino', 'Femenino', 'No binario', 'Prefiero no responder'].includes(genero)) {
        mostrarError('genero', 'Por favor, seleccione un género válido.');
        return;
    }

    var correo = document.getElementById('correo').value;
    if (!/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(correo)) {
        mostrarError('correo', 'Por favor, ingrese un correo electrónico válido.');
        return;
    }

    var celular = document.getElementById('celular').value;
    if (!/^\d{10}$/.test(celular)) {
        mostrarError('celular', 'Por favor, ingrese un número de celular válido (10 dígitos).');
        return;
    }    

    var tipoDocumento = document.getElementById('tipoDocumentoLA').value;

    enviarDatosAlServidor(tipoDocumento, numeroDocumento, primerNombre, segundoNombre, apellidos, fechaNacimiento, genero, correo, celular);
}

function enviarDatosAlServidor(tipoDocumento, numeroDocumento, primerNombre, segundoNombre, apellidos, fechaNacimiento, genero, correo, celular) {
    
    fetch(`/actualizarDB/${numeroDocumento}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `tipoDocumento=${encodeURIComponent(tipoDocumento)}&numeroDocumento=${encodeURIComponent(numeroDocumento)}&primerNombre=${encodeURIComponent(primerNombre)}&segundoNombre=${encodeURIComponent(segundoNombre)}&apellidos=${encodeURIComponent(apellidos)}&fechaNacimiento=${encodeURIComponent(fechaNacimiento)}&genero=${encodeURIComponent(genero)}&correo=${encodeURIComponent(correo)}&celular=${encodeURIComponent(celular)}`
    })
    .then(response => response.text())
    .then(data => {
        // Manejar la respuesta del servidor si es necesario
        console.log(data);
    })
    .catch(error => console.error('Error:', error));
}

function mostrarError(campo, mensaje) {
    // Muestra el mensaje de error y resalta el campo con un borde rojo.
    document.getElementById(campo).classList.add('invalid');
    document.getElementById(campo + 'Error').innerText = mensaje;
}

function limpiarErrores() {
    // Limpiar mensajes de error y estilos de validación.
    var campos = ['numeroDocumento', 'primerNombre', 'segundoNombre', 'apellidos', 'fechaNacimiento', 'genero', 'correo', 'celular'];
    campos.forEach(function (campo) {
        document.getElementById(campo).classList.remove('invalid');
        document.getElementById(campo + 'Error').innerText = '';
    });
}
