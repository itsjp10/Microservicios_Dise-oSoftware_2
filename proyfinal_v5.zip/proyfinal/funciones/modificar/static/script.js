
function activarBoton(boton) {
    document.querySelectorAll('.boton-azul').forEach(function(el) {
        el.classList.remove('activo');
    });
    boton.classList.add('activo');
}

function buscarPorDocumento() { 
    var numeroDocumento = document.getElementById('documento').value;
    var cuadroResultados = document.getElementById('cuadro-resultados');

    // Simula los resultados de la consulta (puedes ajustar esto según tu lógica real)
    var resultados = "Resultados para el número de documento " + numeroDocumento;
    cuadroResultados.innerHTML = resultados;
}

function closeBanner(element) {
    var banner = element.parentNode; // Obtener el elemento padre del span (el banner)
    banner.parentNode.removeChild(banner); // Eliminar el banner del DOM
}

 
//BOTONES

function crear_boton(){
    window.location.href = "http://localhost:5002/crear_personas";
}

function modificar_boton(){
    window.location.href = "http://localhost:5005/actualizar";
}

function consultar_boton(){
    window.location.href = "http://localhost:5001/consultar";
}

function borrar_boton(){
    window.location.href = "http://localhost:5004/eliminar";
}

function consultarlog_boton(){
    window.location.href = "http://localhost:5003/consultar_log";
}




//FUNCIONES DE JS PARA MODIFICAR PERSONA

function verPersona() {
    var numeroDocumento = document.getElementById('numeroDocumento').value;
    if (!numeroDocumento || isNaN(numeroDocumento) || numeroDocumento.length > 10) {
        // Mostrar mensaje de error y resaltar el campo.
        mostrarError('numeroDocumento', 'Por favor, ingrese un número de documento válido (hasta 10 dígitos).');
        return;
    }    
    window.location.href = "/actualizar/"+numeroDocumento;
    //document.getElementById('formularioEdicion').style.display = 'block';
}

function actualizarPersona() {
    

    // Validar campos antes de actualizar la información.
    var numeroDocumento = document.getElementById('numeroDocumentoLA').value;

    var primerNombre = document.getElementById('primerNombre').value;
    if (!primerNombre || !/^[a-zA-Z]+$/.test(primerNombre) || primerNombre.length > 30) {
        mostrarError('primerNombre', 'Por favor, ingrese un primer nombre válido (no números, hasta 30 caracteres).');
        return;
    }

    var segundoNombre = document.getElementById('segundoNombre').value;
    if (!/^[a-zA-Z]*$/.test(segundoNombre) || segundoNombre.length > 30) {
        mostrarError('segundoNombre', 'Por favor, ingrese un segundo nombre válido (no números, hasta 30 caracteres).');
        return;
    }
    var apellidos = document.getElementById('apellidos').value;
    if (!/^([a-zA-Z]+\s?)+$/.test(apellidos) || apellidos.length > 60) {
        mostrarError('apellidos', 'Por favor, ingrese apellidos válidos (no números, hasta 60 caracteres).');
        return;
    }

    var fechaNacimiento = document.getElementById('fechaNacimiento').value;
    // Validación de la fecha de nacimiento puede requerir una lógica más compleja (se puede usar una biblioteca como moment.js).

    var genero = document.getElementById('genero').value;
    if (!['Masculino', 'Femenino', 'No binario', 'Prefiero no responder'].includes(genero)) {
        mostrarError('genero', 'Por favor, seleccione un género válido.');
        return;
    }

    var correo = document.getElementById('correo').value;
    if (!/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(correo)) {
        mostrarError('correo', 'Por favor, ingrese un correo electrónico válido.');
        return;
    }

    var celular = document.getElementById('celular').value;
    if (!/^\d{10}$/.test(celular)) {
        mostrarError('celular', 'Por favor, ingrese un número de celular válido (10 dígitos).');
        return;
    }    

    var tipoDocumento = document.getElementById('tipoDocumentoLA').value;

    enviarDatosAlServidor(tipoDocumento, numeroDocumento, primerNombre, segundoNombre, apellidos, fechaNacimiento, genero, correo, celular);
}

function enviarDatosAlServidor(tipoDocumento, numeroDocumento, primerNombre, segundoNombre, apellidos, fechaNacimiento, genero, correo, celular) {
    
    fetch(`/actualizarDB/${numeroDocumento}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `tipoDocumento=${encodeURIComponent(tipoDocumento)}&numeroDocumento=${encodeURIComponent(numeroDocumento)}&primerNombre=${encodeURIComponent(primerNombre)}&segundoNombre=${encodeURIComponent(segundoNombre)}&apellidos=${encodeURIComponent(apellidos)}&fechaNacimiento=${encodeURIComponent(fechaNacimiento)}&genero=${encodeURIComponent(genero)}&correo=${encodeURIComponent(correo)}&celular=${encodeURIComponent(celular)}`
    })
    .then(response => response.text())
    .then(data => {
        // Manejar la respuesta del servidor
        if (data = '1') {
            window.location.href = '/exito';  // Ruta a la página de éxito
        } else {
            window.location.href = '/fallo';  // Ruta a la página de fallo
        }
    })
    .catch(error => console.error('Error:', error));
    
}


function mostrarError(campo, mensaje) {
    // Muestra el mensaje de error y resalta el campo con un borde rojo.
    var campoElement = document.getElementById(campo);
    var errorElement = document.getElementById(campo + 'Error');
    
    campoElement.classList.add('invalid');
    errorElement.innerText = mensaje;
}

function limpiarErrores() {
    // Limpiar mensajes de error y estilos de validación.
    var campos = ['numeroDocumento', 'primerNombre', 'segundoNombre', 'apellidos', 'fechaNacimiento', 'genero', 'correo', 'celular'];
    
    campos.forEach(function (campo) {
        var campoElement = document.getElementById(campo);
        var errorElement = document.getElementById(campo + 'Error');

        campoElement.classList.remove('invalid');
        errorElement.innerText = '';
    });
}


