from flask import Flask, render_template, request, jsonify, redirect, url_for
from sqlalchemy import create_engine
import psycopg2
import logging

app = Flask(__name__)

messages = []

logging.basicConfig(level=logging.DEBUG)
logging.debug("MODIFICAR SERVICE INICIADO")


def actualizar(numero_documento, tipo_documento, primer_nombre, segundo_nombre, apellidos, fecha_nacimiento, genero, correo_electronico, celular):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )        
        cursor = conn.cursor()
        logging.debug("pre-query")
        query = f"""
            UPDATE perfil 
            SET tipo_documento = '{tipo_documento}', primer_nombre = '{primer_nombre}', segundo_nombre = '{segundo_nombre}', apellidos = '{apellidos}', fecha_nacimiento = '{fecha_nacimiento}', genero = '{genero}', correo_electronico = '{correo_electronico}', celular = '{celular}'
            WHERE numero_documento = {numero_documento}; 
        """        
        cursor.execute(query)
        query = f"INSERT INTO log (descripcion, tipo_documento, numero_documento) VALUES ('Se actualizaron los datos de la persona', '{log(numero_documento)}', {numero_documento});"
        cursor.execute(query) #nothing to fetch as this query has nothing to show
        conn.commit()            
        logging.debug("persona actualizada!")
        return 1
                            
        
    except Exception as ex:
        logging.debug("error principal")
        logging.debug(ex)    


def log(numero_documento):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )
        cursor = conn.cursor()        
        query = f"SELECT tipo_documento FROM perfil WHERE numero_documento = {numero_documento};"   
        cursor.execute(query)
        conn.commit()
        result = cursor.fetchall()  #acá el resultado puede ser un count o un select con todas las columnas de la tabla
        return result[0][0]

    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)


def consulta(tipo_consulta, numero_documento):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )        
        cursor = conn.cursor()
        if(tipo_consulta == 1):
            logging.debug("entrando consultar el doc")
            query = f"SELECT COUNT (*) FROM perfil WHERE numero_documento = {numero_documento};"
            cursor.execute(query)
            result = cursor.fetchall()    
            logging.debug("Probando el result = "+str(result[0][0]))
            return result

        elif(tipo_consulta == 2): #
            query = f"SELECT * FROM perfil WHERE numero_documento = {numero_documento};"
            cursor.execute(query) #nothing to fetch as this query has nothing to show
            result = cursor.fetchall()   
            return result
            
                            
        
    except Exception as ex:
        logging.debug("error secundario")
        logging.debug(ex)



@app.route('/actualizarDB/<int:numero_documento>', methods=['POST'])
def actualizar_persona(numero_documento):    
    try:                     
        count = consulta(1, numero_documento)[0][0]             
        if (count == 0):
            # no hay ninguna persona con ese documento
            message = {'type': 'error', 'content': 'Esta persona no existe'}
            result = {}
            return render_template('modificar.html', message=message, persona=result)
        else:
            #sí hay alguien que tenga ese documento
            logging.debug("Antes de recoger los valores")
            
            tipo_documento = request.form['tipoDocumento']
            logging.debug("Tipo de documento agarrado")
            
            primer_nombre = request.form['primerNombre']
            segundo_nombre = request.form['segundoNombre']
            apellidos = request.form['apellidos']   
            fecha_nacimiento = request.form['fechaNacimiento']
            genero = request.form['genero']
            correo_electronico = request.form['correo']
            celular = request.form['celular']    
            logging.debug("acá recoge todos los datos del forms")
            
            respuesta = actualizar(numero_documento, tipo_documento, primer_nombre, segundo_nombre, apellidos, fecha_nacimiento, genero, correo_electronico, celular)
            if respuesta == 1: #1 = éxito
                return '1'
            else:
                return '0'
        
    
    
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)
        #error al intentar "conectarse a la base de datos"
        message = {'type': 'error', 'content': 'Error actualizando persona'}
        result = {}
        return render_template('modificar.html', message=message, persona=result)    
    


@app.route('/actualizar/<numero_documento>') #cuando ya se oprime el botón de ver persona
def ver_persona(numero_documento):
    try:                     
        count = consulta(1, numero_documento)[0][0]        
        if (count == 0):
            # no hay ninguna persona con ese documento
            message = {'type': 'error', 'content': 'Esta persona no existe'}
            result = {}
            #se intentó actualizar los datos de la persona <no. doc> pero esta no existe
            return render_template('modificar.html', message=message, persona=result)
        else:
            #sí hay alguien que tenga ese documento
            result = consulta(2, numero_documento)
            message = {}
            return render_template('modificar.html', message=message, persona=result)
            
    
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)
        #no se pudo encontrar la persona en la base de datos
        message = {'type': 'error', 'content': 'Error. Por favor revise la conexión a la base de datos'}   
        result = {}
        return render_template('modificar.html', message=message, persona=result)


@app.route('/exito', methods=['GET'])
def exito():
    message = {'type': 'success', 'content': 'La persona se actualizó correctamente'}
    result = {}  # Aquí podrías incluir más datos si los necesitas
    return render_template('modificar.html', message=message, persona=result)

@app.route('/fallo', methods=['GET'])
def fallo():
    message = {'type': 'error', 'content': 'La persona no se actualizó'}
    result = {}  
    return render_template('modificar.html', message=message, persona=result)


@app.route('/actualizar')  #cuando no hay ninguna acción del usuario
def mostrar_primer_form():
        try:
            #error al intentar "conectarse a la base de datos"
            message = {}   
            result = {}
            return render_template('modificar.html', message=message, persona=result)
        except:
            #error al intentar "conectarse a la base de datos"
            message = {}   
            result = {}
            return render_template('modificar.html', message=message, persona=result)



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)