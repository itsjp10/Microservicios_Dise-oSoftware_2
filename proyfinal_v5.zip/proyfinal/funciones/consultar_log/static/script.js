
function activarBoton(boton) {
    document.querySelectorAll('.boton-azul').forEach(function(el) {
        el.classList.remove('activo');
    });
    boton.classList.add('activo');
}

function closeBanner(element) {
    var banner = element.parentNode; // Obtener el elemento padre del span (el banner)
    banner.parentNode.removeChild(banner); // Eliminar el banner del DOM
}

 
//BOTONES

function crear_boton(){
    window.location.href = "http://localhost:5002/crear_personas";
}

function modificar_boton(){
    window.location.href = "http://localhost:5005/actualizar";
}

function consultar_boton(){
    window.location.href = "http://localhost:5001/consultar";
}

function borrar_boton(){
    window.location.href = "http://localhost:5004/eliminar";
}

function consultarlog_boton(){
    window.location.href = "http://localhost:5003/consultar_log";
}




//FUNCIONES PARA CONSULTAR LOG
function buscarPersona(){
    var numeroDocumento = document.getElementById('numeroDocumento').value;
    var tipoDocumento = document.getElementById('tipoDocumento').value;
    var fecha = document.getElementById('fecha').value;

    // Verificar si la búsqueda es posible (al menos un campo debe tener valor)
    if (numeroDocumento.trim() === '' && tipoDocumento.trim() === '' && fecha.trim() === '') {
        mostrarError('mensajeError', 'Ingrese al menos un criterio de búsqueda.');
        return;
    }

    // Verificar la validez del número de documento si se proporciona
    if (numeroDocumento.trim() !== '' && !/^\d{1,10}$/.test(numeroDocumento)) {
        mostrarError('numeroDocumento', 'Ingrese un número de documento válido (solo números, hasta 10 dígitos).');
        return;
    }

    // Caso 1: Búsqueda por (tipoDoc y numeroDoc)
    if (tipoDocumento.trim() !== '' && numeroDocumento.trim() !== '' && fecha.trim() === '') {
        if (tipoDocumento.trim() !== '' && /^\d{1,10}$/.test(numeroDocumento)) {
            // Redirige a la ruta correspondiente
            window.location.href = '/log/' + tipoDocumento + '/' + numeroDocumento;
        }
        return;
    }

    // Caso 2: Búsqueda solo por fecha
    if (tipoDocumento.trim() === '' && numeroDocumento.trim() === '' && fecha.trim() !== '') {
        if (fecha.trim() !== '') {
            // Redirige a la ruta correspondiente
            window.location.href = '/log/' + fecha;
        }
        return;
    }

    // Caso 3: Búsqueda por (tipoDoc, numeroDoc, fecha)
    if (tipoDocumento.trim() !== '' && numeroDocumento.trim() !== '' && fecha.trim() !== '') {
        if (tipoDocumento.trim() !== '' && /^\d{1,10}$/.test(numeroDocumento) && fecha.trim() !== '') {
            // Redirige a la ruta correspondiente
            window.location.href = '/log/' + tipoDocumento + '/' + numeroDocumento + '/' + fecha;
        }
        return;
    }

    // En este punto, se puede asumir que la combinación de criterios no es reconocida.
    mostrarError('mensajeError', 'La combinación de criterios de búsqueda no es válida.');
}

function mostrarError(campo, mensaje) {
    // Muestra el mensaje de error y resalta el campo con un borde rojo.
    var campoElement = document.getElementById(campo);
    campoElement.classList.add('invalid');
    campoElement.innerText = mensaje;
}

