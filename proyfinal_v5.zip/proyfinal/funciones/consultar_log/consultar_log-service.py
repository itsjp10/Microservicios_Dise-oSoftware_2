from flask import Flask, render_template, request, jsonify
from sqlalchemy import create_engine
import psycopg2
import logging

app = Flask(__name__)

messages = []

logging.basicConfig(level=logging.DEBUG)
logging.debug("CONSULTAR_LOG SERVICE INICIADO")





def consulta(query):
    db_name = 'rainbow_database'
    db_user = 'unicorn_user'
    db_pass = 'magical_password'
    db_host = 'database-service'
    db_port = '5432'

    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            database=db_name,
            user=db_user,
            password=db_pass
        )
        cursor = conn.cursor()        
        cursor.execute(query)

        result = cursor.fetchall()

        return result
        

    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)



@app.route('/log/<tipo_documento>/<int:numero_documento>')
def buscar_tipo_numero(tipo_documento, numero_documento):
    try:
        query = f"SELECT COUNT(*) FROM log WHERE numero_documento = {numero_documento} AND tipo_documento = '{tipo_documento}';"
        logging.debug(query)
        count = consulta(query)[0][0]
        if (count == 0):
            message = {'type': 'neutral', 'content': 'No se encontraron resultados'}
            result = {}
            return render_template('consultar_log.html', message=message, persona=result)
        else:
            query = f"SELECT * FROM log WHERE numero_documento = {numero_documento} AND tipo_documento = '{tipo_documento}';"
            logging.debug(query)
            message = {}
            result = consulta(query)
            logging.debug(result)
            return render_template('consultar_log.html', message=message, persona=result)
            #Se encontraron resultados
        
    
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)
        message = {}   
        result = {}
        return render_template('consultar_log.html', message=message, persona=result)




# Endpoint para búsqueda solo por fecha
@app.route('/log/<fecha>')
def buscar_fecha(fecha):
    try:
        query = f"SELECT COUNT(*) FROM log WHERE DATE(fecha) = '{fecha}';"
        logging.debug(query)
        count = consulta(query)[0][0]
        if (count == 0):
            message = {'type': 'neutral', 'content': 'No se encontraron resultados'}
            result = {}
            return render_template('consultar_log.html', message=message, persona=result)
        else:
            query = f"SELECT * FROM log WHERE DATE(fecha) = '{fecha}';"
            logging.debug(query)
            message = {}
            result = consulta(query)
            logging.debug(result)

            return render_template('consultar_log.html', message=message, persona=result)
            #Se encontraron resultados
        
    
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)
        message = {}   
        result = {}
        return render_template('consultar_log.html', message=message, persona=result)





# Endpoint para búsqueda por (tipoDoc, numeroDoc, fecha)
@app.route('/log/<tipo_documento>/<int:numero_documento>/<fecha>')
def buscar_combinado(tipo_documento, numero_documento, fecha):
    try:
        query = f"SELECT COUNT(*) FROM log WHERE DATE(fecha) = '{fecha}' AND numero_documento = {numero_documento} AND tipo_documento = '{tipo_documento}';"
        logging.debug(query)
        count = consulta(query)[0][0]
        if (count == 0):
            message = {'type': 'neutral', 'content': 'No se encontraron resultados'}
            result = {}
            return render_template('consultar_log.html', message=message, persona=result)
        else:
            query = f"SELECT * FROM log WHERE DATE(fecha) = '{fecha}' AND numero_documento = {numero_documento} AND tipo_documento = '{tipo_documento}';"
            logging.debug(query)
            message = {}
            result = consulta(query)
            logging.debug(result)

            return render_template('consultar_log.html', message=message, persona=result)
            #Se encontraron resultados
        
    
    except Exception as ex:
        logging.debug("error")
        logging.debug(ex)
        message = {}   
        result = {}
        return render_template('consultar_log.html', message=message, persona=result)




@app.route('/consultar_log')
def consultar_log():
    try:        
        message = {}   
        result = {}
        return render_template('consultar_log.html', message=message, persona=result)
    except:        
        message = {}   
        result = {}
        return render_template('consultar_log.html', message=message, persona=result)

    
                




if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)